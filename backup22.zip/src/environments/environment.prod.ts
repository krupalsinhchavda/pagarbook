export const environment = {
  production: true,
  baseUrl: 'your project root API goes here'
};

