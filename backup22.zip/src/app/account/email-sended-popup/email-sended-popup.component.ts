import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-sended-popup',
  templateUrl: './email-sended-popup.component.html',
  styleUrls: ['./email-sended-popup.component.css']
})
export class EmailSendedPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
