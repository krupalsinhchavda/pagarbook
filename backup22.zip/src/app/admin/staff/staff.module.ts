import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StaffRoutingModule } from './staff-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StaffRoutingModule
  ]
})
export class StaffModule { }
