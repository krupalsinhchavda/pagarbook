import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashbook',
  templateUrl: './cashbook.component.html',
  styleUrls: ['./cashbook.component.css']
})
export class CashbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
