import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CashbookRoutingModule } from './cashbook-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CashbookRoutingModule
  ]
})
export class CashbookModule { }
