import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payrolls',
  templateUrl: './payrolls.component.html',
  styleUrls: ['./payrolls.component.css']
})
export class PayrollsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
