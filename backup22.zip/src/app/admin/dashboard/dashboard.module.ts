import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DetailsAttedanceComponent } from './details-attedance/details-attedance.component';
import { DashboardComponent } from './dashboard.component';


@NgModule({
  declarations: [DashboardComponent,
    DetailsAttedanceComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule
  ]
})
export class DashboardModule { }
