import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-attedance',
  templateUrl: './details-attedance.component.html',
  styleUrls: ['./details-attedance.component.css']
})
export class DetailsAttedanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
